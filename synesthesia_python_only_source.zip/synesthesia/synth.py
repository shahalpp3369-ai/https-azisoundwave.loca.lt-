"""
Synesthesia engine.

Turns any piece of text into:
  * an emotional analysis (valence / energy / dominant emotion)
  * a colour palette
  * a generative SVG artwork
  * a tiny poem
  * a melody rendered to WAV

Everything is deterministic: the same text always produces the same creation.
Only the Python standard library is used.
"""

from __future__ import annotations

import colorsys
import hashlib
import io
import math
import random
import re
import struct
import wave
from array import array
from functools import lru_cache

# ---------------------------------------------------------------------------
# Emotion lexicon
# ---------------------------------------------------------------------------

EMOTIONS: dict[str, dict] = {
    "joy": {
        "hue": 45, "valence": 1.0, "energy": 0.8, "style": "bloom", "scale": "major",
        "words": {
            "happy", "joy", "sun", "sunny", "laugh", "smile", "bright", "celebrate", "party",
            "fun", "dance", "glad", "delight", "cheer", "gold", "golden", "summer", "yay",
            "awesome", "amazing", "great", "wonderful", "play", "sing", "festival", "win",
            "hope", "free", "light", "shine", "warm", "birthday", "excited", "good",
        },
    },
    "love": {
        "hue": 340, "valence": 0.9, "energy": 0.5, "style": "bloom", "scale": "pentatonic",
        "words": {
            "love", "heart", "kiss", "darling", "dear", "sweet", "tender", "hug", "romance",
            "beloved", "adore", "together", "rose", "roses", "soul", "embrace", "crush",
            "forever", "honey", "affection", "care", "gentle", "you", "mine", "valentine",
        },
    },
    "calm": {
        "hue": 190, "valence": 0.5, "energy": 0.15, "style": "waves", "scale": "pentatonic",
        "words": {
            "calm", "peace", "quiet", "still", "ocean", "sea", "breeze", "soft", "slow",
            "breathe", "rest", "sleep", "serene", "gentle", "tide", "lake", "float", "zen",
            "silence", "meditate", "relax", "cozy", "tea", "rain", "morning", "cloud", "clouds",
        },
    },
    "wonder": {
        "hue": 270, "valence": 0.6, "energy": 0.6, "style": "orbits", "scale": "lydian",
        "words": {
            "star", "stars", "space", "galaxy", "cosmos", "universe", "moon", "planet", "dream",
            "dreams", "magic", "mystery", "infinite", "wonder", "curious", "explore", "night",
            "sky", "orbit", "nebula", "why", "imagine", "future", "strange", "secret", "time",
        },
    },
    "nature": {
        "hue": 125, "valence": 0.4, "energy": 0.4, "style": "flow", "scale": "dorian",
        "words": {
            "tree", "trees", "forest", "leaf", "leaves", "river", "grow", "green", "garden",
            "flower", "flowers", "moss", "mountain", "wild", "earth", "root", "roots", "bloom",
            "spring", "bird", "birds", "meadow", "fern", "wind", "path", "wood", "woods",
        },
    },
    "melancholy": {
        "hue": 220, "valence": -0.7, "energy": 0.2, "style": "rain", "scale": "minor",
        "words": {
            "sad", "alone", "lonely", "tears", "tear", "cry", "lost", "miss", "goodbye", "grey",
            "gray", "empty", "cold", "winter", "memory", "memories", "forgot", "gone", "regret",
            "blue", "sorrow", "grief", "broken", "fade", "faded", "ache", "nostalgia", "never",
        },
    },
    "anger": {
        "hue": 5, "valence": -0.8, "energy": 0.95, "style": "shards", "scale": "phrygian",
        "words": {
            "angry", "rage", "hate", "fire", "burn", "burning", "fury", "fight", "scream",
            "storm", "war", "break", "smash", "mad", "furious", "blood", "rebel", "chaos",
            "thunder", "explode", "riot", "danger", "fierce", "hell", "damn", "annoyed",
        },
    },
    "fear": {
        "hue": 255, "valence": -0.6, "energy": 0.7, "style": "shards", "scale": "phrygian",
        "words": {
            "fear", "afraid", "scared", "dark", "darkness", "shadow", "shadows", "nightmare",
            "panic", "anxious", "worry", "ghost", "haunted", "terror", "creep", "hide",
            "trapped", "alone", "deep", "abyss", "unknown", "monster", "tremble", "doubt",
        },
    },
}

EMOTION_NAMES = list(EMOTIONS)

# Poetic vocabulary for titles & verses
VOCAB: dict[str, dict[str, list[str]]] = {
    "joy": {
        "adj": ["gilded", "radiant", "sunlit", "dancing", "honeyed", "electric"],
        "noun": ["morning", "festival", "laughter", "marigold", "confetti", "daybreak"],
        "verb": ["spills", "spins", "sparkles", "leaps", "hums", "blazes"],
        "end": ["becomes the sun.", "laughs out loud.", "refuses to dim.", "is everywhere."],
    },
    "love": {
        "adj": ["tender", "rose-lit", "velvet", "breathless", "warm", "devoted"],
        "noun": ["embrace", "heartbeat", "whisper", "promise", "ember", "petal"],
        "verb": ["lingers", "softens", "blooms", "glows", "returns", "holds"],
        "end": ["stays a little longer.", "is enough.", "learns your name.", "never lets go."],
    },
    "calm": {
        "adj": ["still", "silver", "unhurried", "tidal", "hushed", "pale"],
        "noun": ["harbor", "breath", "shoreline", "mist", "lagoon", "lull"],
        "verb": ["drifts", "settles", "ebbs", "rests", "floats", "slows"],
        "end": ["breathes out slowly.", "asks for nothing.", "is the tide.", "sinks into quiet."],
    },
    "wonder": {
        "adj": ["cosmic", "luminous", "orbiting", "nebulous", "starborn", "infinite"],
        "noun": ["nebula", "constellation", "reverie", "comet", "horizon", "aurora"],
        "verb": ["orbits", "unfolds", "glimmers", "wanders", "beckons", "expands"],
        "end": ["opens like a door.", "is made of stars.", "keeps on asking.", "has no edge."],
    },
    "nature": {
        "adj": ["mossy", "verdant", "wild", "rooted", "dew-soaked", "feral"],
        "noun": ["canopy", "fern", "river", "thicket", "meadow", "grove"],
        "verb": ["unfurls", "climbs", "winds", "grows", "whispers", "branches"],
        "end": ["takes root.", "grows toward light.", "remembers the rain.", "is alive."],
    },
    "melancholy": {
        "adj": ["faded", "rain-soft", "distant", "hollow", "pale", "wistful"],
        "noun": ["letter", "window", "echo", "november", "photograph", "ghostlight"],
        "verb": ["fades", "lingers", "falls", "waits", "dissolves", "remembers"],
        "end": ["is still raining.", "was almost forgotten.", "waits by the window.", "goes quiet."],
    },
    "anger": {
        "adj": ["molten", "jagged", "scorched", "crimson", "thunderous", "feral"],
        "noun": ["wildfire", "fracture", "storm", "furnace", "eruption", "blade"],
        "verb": ["shatters", "burns", "erupts", "cracks", "roars", "tears"],
        "end": ["will not be silenced.", "breaks the glass.", "burns it down.", "roars back."],
    },
    "fear": {
        "adj": ["hollow", "shadowed", "trembling", "midnight", "silent", "sunken"],
        "noun": ["abyss", "corridor", "shadow", "static", "undertow", "threshold"],
        "verb": ["creeps", "trembles", "hides", "circles", "pulls", "watches"],
        "end": ["is right behind you.", "holds its breath.", "never blinks.", "waits below."],
    },
}

PREPOSITIONS = ["through", "across", "beneath", "beyond", "inside", "over"]

SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "pentatonic": [0, 2, 4, 7, 9],
    "dorian": [0, 2, 3, 5, 7, 9, 10],
    "lydian": [0, 2, 4, 6, 7, 9, 11],
    "phrygian": [0, 1, 3, 5, 7, 8, 10],
}

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

WORD_RE = re.compile(r"[a-zA-Z']+")


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def _variants(word: str) -> set[str]:
    """Very small stemmer so 'dreaming', 'dreamed', 'dreams' all match 'dream'."""
    w = word.strip("'")
    out = {w}
    for suffix in ("ing", "ed", "es", "s", "ly", "y", "er"):
        if w.endswith(suffix) and len(w) - len(suffix) >= 3:
            out.add(w[: -len(suffix)])
    return out


def _seed_for(text: str) -> int:
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:12], 16)


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def analyze(text: str) -> dict:
    words = [w.lower() for w in WORD_RE.findall(text)]
    seed = _seed_for(text)
    scores = {e: 0.0 for e in EMOTIONS}
    matched: list[str] = []

    for w in words:
        hit = False
        for cand in _variants(w):
            for name, data in EMOTIONS.items():
                if cand in data["words"]:
                    scores[name] += 1
                    hit = True
        if hit and w not in matched:
            matched.append(w)

    # Punctuation & shouting nudge the mood.
    exclaims = text.count("!")
    questions = text.count("?")
    letters = [c for c in text if c.isalpha()]
    upper_ratio = (sum(c.isupper() for c in letters) / len(letters)) if letters else 0
    scores["wonder"] += questions * 0.5
    if exclaims:
        scores["joy"] += exclaims * 0.3
        scores["anger"] += exclaims * 0.2 if upper_ratio > 0.5 else 0

    total = sum(scores.values())
    if total == 0:
        # No known words: let the text's fingerprint choose a mood.
        primary = EMOTION_NAMES[seed % len(EMOTION_NAMES)]
        secondary = EMOTION_NAMES[(seed // 7) % len(EMOTION_NAMES)]
        scores[primary] = 2.0
        scores[secondary] += 1.0
        total = sum(scores.values())

    weights = {e: s / total for e, s in scores.items()}
    dominant = max(weights, key=weights.get)

    valence = sum(weights[e] * EMOTIONS[e]["valence"] for e in EMOTIONS)
    energy = sum(weights[e] * EMOTIONS[e]["energy"] for e in EMOTIONS)
    energy = _clamp(energy + min(exclaims, 5) * 0.04 + (0.15 if upper_ratio > 0.6 else 0))

    # Circular weighted mean of hues.
    x = sum(weights[e] * math.cos(math.radians(EMOTIONS[e]["hue"])) for e in EMOTIONS)
    y = sum(weights[e] * math.sin(math.radians(EMOTIONS[e]["hue"])) for e in EMOTIONS)
    hue = (math.degrees(math.atan2(y, x)) + 360) % 360
    hue = (hue + (seed % 21) - 10) % 360  # tiny unique drift per text

    top = sorted(
        ({"name": e, "weight": round(w, 3)} for e, w in weights.items() if w > 0),
        key=lambda d: d["weight"],
        reverse=True,
    )[:4]

    return {
        "seed": seed,
        "dominant": dominant,
        "valence": round(valence, 3),
        "energy": round(energy, 3),
        "hue": round(hue, 1),
        "emotions": top,
        "matched": matched[:12],
        "word_count": len(words),
        "words": words,
    }


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------

def _hex(h: float, l: float, s: float) -> str:
    r, g, b = colorsys.hls_to_rgb(h % 1.0, _clamp(l), _clamp(s))
    return "#{:02x}{:02x}{:02x}".format(round(r * 255), round(g * 255), round(b * 255))


def make_palette(a: dict, rng: random.Random) -> dict:
    base = a["hue"] / 360
    sat = 0.45 + 0.45 * a["energy"]
    light = 0.52 + 0.12 * a["valence"]

    schemes = {
        "analogous": [0, 0.05, -0.05, 0.1, -0.1],
        "complementary": [0, 0.04, 0.5, 0.46, -0.04],
        "triadic": [0, 0.333, 0.667, 0.03, 0.36],
        "split": [0, 0.42, 0.58, 0.05, -0.05],
    }
    if a["valence"] < -0.3:
        scheme = "analogous"
    elif a["energy"] > 0.7:
        scheme = rng.choice(["complementary", "triadic", "split"])
    else:
        scheme = rng.choice(list(schemes))

    light_curve = [0.0, 0.14, -0.12, 0.24, -0.2]
    colors = []
    for off, dl in zip(schemes[scheme], light_curve):
        h = base + off + rng.uniform(-0.015, 0.015)
        colors.append(_hex(h, light + dl, sat + rng.uniform(-0.08, 0.08)))

    background = _hex(base, 0.06 + 0.04 * (a["valence"] + 1) / 2, 0.45)
    background2 = _hex(base + 0.08, 0.14 + 0.05 * (a["valence"] + 1) / 2, 0.5)
    return {"colors": colors, "background": background, "background2": background2, "scheme": scheme}


# ---------------------------------------------------------------------------
# Generative art (SVG)
# ---------------------------------------------------------------------------

def _f(v: float) -> str:
    return f"{v:.1f}"


def _art_flow(rng, colors, energy):
    parts = []
    n = 22 + int(energy * 26)
    for i in range(n):
        c = colors[i % len(colors)]
        y0 = rng.uniform(-50, 650)
        y1 = y0 + rng.uniform(-200, 200)
        amp = 120 + energy * 260
        d = (
            f"M -60 {_f(y0)} C {_f(rng.uniform(100, 250))} {_f(y0 + rng.uniform(-amp, amp))}, "
            f"{_f(rng.uniform(350, 500))} {_f(y1 + rng.uniform(-amp, amp))}, 660 {_f(y1)}"
        )
        w = rng.uniform(1.5, 26) * (1 - i / (n * 1.4))
        parts.append(
            f'<path d="{d}" fill="none" stroke="{c}" stroke-width="{_f(w)}" '
            f'stroke-linecap="round" opacity="{rng.uniform(0.18, 0.75):.2f}"/>'
        )
    return "".join(parts)


def _art_waves(rng, colors, energy):
    parts = []
    layers = 11
    for i in range(layers):
        base = 120 + i * 46
        amp = 8 + energy * 40 + rng.uniform(0, 18)
        freq = rng.uniform(0.006, 0.02)
        phase = rng.uniform(0, math.tau)
        pts = [f"M -10 {_f(base)}"]
        for x in range(0, 621, 12):
            y = base + amp * math.sin(x * freq + phase) + amp * 0.35 * math.sin(x * freq * 2.7 + phase)
            pts.append(f"L {x} {_f(y)}")
        pts.append("L 620 620 L -10 620 Z")
        c = colors[i % len(colors)]
        parts.append(f'<path d="{" ".join(pts)}" fill="{c}" opacity="{0.16 + i * 0.05:.2f}"/>')
    # a soft moon
    parts.append(
        f'<circle cx="{_f(rng.uniform(140, 460))}" cy="{_f(rng.uniform(70, 150))}" r="{_f(rng.uniform(26, 50))}" '
        f'fill="{colors[3]}" opacity="0.85"/>'
    )
    return "".join(parts)


def _art_orbits(rng, colors, energy, uid):
    parts = []
    for _ in range(110):
        parts.append(
            f'<circle cx="{_f(rng.uniform(0, 600))}" cy="{_f(rng.uniform(0, 600))}" '
            f'r="{rng.uniform(0.4, 2.0):.2f}" fill="#fff" opacity="{rng.uniform(0.2, 0.9):.2f}"/>'
        )
    cx, cy = 300 + rng.uniform(-40, 40), 300 + rng.uniform(-40, 40)
    parts.append(f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="46" fill="url(#core{uid})"/>')
    rings = 7
    for i in range(rings):
        r = 70 + i * 30 + rng.uniform(-6, 6)
        c = colors[i % len(colors)]
        dash = f"{rng.randint(2, 40)} {rng.randint(4, 30)}"
        dur = rng.uniform(30, 90) / (0.5 + energy)
        direction = 360 if i % 2 == 0 else -360
        angle = rng.uniform(0, 360)
        px = cx + r * math.cos(math.radians(angle))
        py = cy + r * math.sin(math.radians(angle))
        parts.append(
            f'<g><animateTransform attributeName="transform" type="rotate" '
            f'from="0 {_f(cx)} {_f(cy)}" to="{direction} {_f(cx)} {_f(cy)}" dur="{dur:.1f}s" repeatCount="indefinite"/>'
            f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="{_f(r)}" fill="none" stroke="{c}" '
            f'stroke-width="{rng.uniform(0.8, 3):.1f}" stroke-dasharray="{dash}" opacity="0.7"/>'
            f'<circle cx="{_f(px)}" cy="{_f(py)}" r="{rng.uniform(4, 13):.1f}" fill="{c}"/></g>'
        )
    return "".join(parts)


def _art_bloom(rng, colors, energy):
    parts = []
    cx, cy = 300, 300
    # pollen
    for _ in range(70):
        a = rng.uniform(0, math.tau)
        d = rng.uniform(150, 300)
        parts.append(
            f'<circle cx="{_f(cx + d * math.cos(a))}" cy="{_f(cy + d * math.sin(a))}" '
            f'r="{rng.uniform(1, 4):.1f}" fill="{rng.choice(colors)}" opacity="{rng.uniform(0.3, 0.9):.2f}"/>'
        )
    layers = 5
    for layer in range(layers):
        k = rng.choice([5, 6, 8, 10, 12]) + layer
        ry = 150 - layer * 24
        rx = ry * rng.uniform(0.25, 0.45)
        dist = ry * 0.85
        c = colors[layer % len(colors)]
        offset = rng.uniform(0, 360)
        for p in range(k):
            ang = offset + p * 360 / k
            parts.append(
                f'<ellipse cx="{cx}" cy="{_f(cy - dist)}" rx="{_f(rx)}" ry="{_f(ry * 0.9)}" fill="{c}" '
                f'opacity="{0.35 + layer * 0.1:.2f}" transform="rotate({ang:.1f} {cx} {cy})"/>'
            )
    parts.append(f'<circle cx="{cx}" cy="{cy}" r="26" fill="{colors[3]}"/>')
    parts.append(f'<circle cx="{cx}" cy="{cy}" r="12" fill="{colors[0]}"/>')
    return "".join(parts)


def _art_rain(rng, colors, energy, uid):
    parts = []
    for _ in range(7):
        parts.append(
            f'<ellipse cx="{_f(rng.uniform(0, 600))}" cy="{_f(rng.uniform(0, 250))}" rx="{_f(rng.uniform(120, 260))}" '
            f'ry="{_f(rng.uniform(40, 90))}" fill="{rng.choice(colors)}" opacity="0.22" filter="url(#blur{uid})"/>'
        )
    for _ in range(150):
        x = rng.uniform(0, 600)
        y = rng.uniform(-40, 520)
        length = rng.uniform(18, 110)
        parts.append(
            f'<line x1="{_f(x)}" y1="{_f(y)}" x2="{_f(x - length * 0.12)}" y2="{_f(y + length)}" '
            f'stroke="{rng.choice(colors)}" stroke-width="{rng.uniform(0.6, 2.4):.1f}" '
            f'stroke-linecap="round" opacity="{rng.uniform(0.25, 0.8):.2f}"/>'
        )
    for _ in range(9):
        x, y = rng.uniform(40, 560), rng.uniform(500, 590)
        for r in range(3):
            parts.append(
                f'<ellipse cx="{_f(x)}" cy="{_f(y)}" rx="{_f(14 + r * 16)}" ry="{_f(3 + r * 4)}" fill="none" '
                f'stroke="{colors[3]}" stroke-width="1" opacity="{0.6 - r * 0.18:.2f}"/>'
            )
    return "".join(parts)


def _art_shards(rng, colors, energy):
    parts = []
    cx, cy = rng.uniform(220, 380), rng.uniform(220, 380)
    n = 40 + int(energy * 40)
    for i in range(n):
        a = rng.uniform(0, math.tau)
        spread = rng.uniform(0.05, 0.3)
        r1 = rng.uniform(0, 80)
        r2 = rng.uniform(160, 460)
        pts = [
            (cx + r1 * math.cos(a), cy + r1 * math.sin(a)),
            (cx + r2 * math.cos(a - spread), cy + r2 * math.sin(a - spread)),
            (cx + r2 * 0.8 * math.cos(a + spread), cy + r2 * 0.8 * math.sin(a + spread)),
        ]
        pts_s = " ".join(f"{_f(px)},{_f(py)}" for px, py in pts)
        parts.append(
            f'<polygon points="{pts_s}" fill="{colors[i % len(colors)]}" opacity="{rng.uniform(0.25, 0.85):.2f}"/>'
        )
    # crack lines
    for _ in range(14):
        a = rng.uniform(0, math.tau)
        x, y = cx, cy
        d = [f"M {_f(x)} {_f(y)}"]
        for _ in range(6):
            a += rng.uniform(-0.5, 0.5)
            step = rng.uniform(30, 70)
            x += step * math.cos(a)
            y += step * math.sin(a)
            d.append(f"L {_f(x)} {_f(y)}")
        parts.append(f'<path d="{" ".join(d)}" fill="none" stroke="#fff" stroke-width="1.2" opacity="0.55"/>')
    return "".join(parts)


def make_svg(a: dict, palette: dict, rng: random.Random) -> tuple[str, str]:
    uid = format(a["seed"] % 0xFFFFFF, "x")
    colors = palette["colors"]
    style = EMOTIONS[a["dominant"]]["style"]
    energy = a["energy"]

    if style == "flow":
        body = _art_flow(rng, colors, energy)
    elif style == "waves":
        body = _art_waves(rng, colors, energy)
    elif style == "orbits":
        body = _art_orbits(rng, colors, energy, uid)
    elif style == "bloom":
        body = _art_bloom(rng, colors, energy)
    elif style == "rain":
        body = _art_rain(rng, colors, energy, uid)
    else:
        body = _art_shards(rng, colors, energy)

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" preserveAspectRatio="xMidYMid slice">'
        f"<defs>"
        f'<radialGradient id="bg{uid}" cx="50%" cy="40%" r="75%">'
        f'<stop offset="0%" stop-color="{palette["background2"]}"/>'
        f'<stop offset="100%" stop-color="{palette["background"]}"/></radialGradient>'
        f'<radialGradient id="core{uid}"><stop offset="0%" stop-color="#fff"/>'
        f'<stop offset="45%" stop-color="{colors[3]}"/><stop offset="100%" stop-color="{colors[0]}" stop-opacity="0"/></radialGradient>'
        f'<filter id="blur{uid}"><feGaussianBlur stdDeviation="22"/></filter>'
        f'<filter id="grain{uid}"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch"/>'
        f'<feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.06 0"/></filter>'
        f"</defs>"
        f'<rect width="600" height="600" fill="url(#bg{uid})"/>'
        f"{body}"
        f'<rect width="600" height="600" filter="url(#grain{uid})"/>'
        f"</svg>"
    )
    return svg, style


# ---------------------------------------------------------------------------
# Words: title + poem
# ---------------------------------------------------------------------------

def make_words(a: dict, rng: random.Random) -> tuple[str, list[str]]:
    v = VOCAB[a["dominant"]]
    secondary = a["emotions"][1]["name"] if len(a["emotions"]) > 1 else a["dominant"]
    v2 = VOCAB[secondary]

    title = f"{rng.choice(v['adj']).title()} {rng.choice(v2['noun']).title()}"

    candidates = (
        [w for w in a["matched"] if len(w) > 2]
        or [w for w in a["words"] if len(w) > 3]
        or a["words"]
        or ["everything"]
    )
    anchor = max(candidates, key=lambda w: (len(w) * 7 + _seed_for(w)) % 97)

    adj1, adj2 = rng.sample(v["adj"], 2)
    noun1 = rng.choice(v["noun"])
    noun2 = rng.choice(v2["noun"])
    poem = [
        f"{adj1.capitalize()} {noun1} {rng.choice(v['verb'])}",
        f"{rng.choice(PREPOSITIONS)} the {adj2} {noun2} —",
        f"and {anchor} {rng.choice(v['end'])}",
    ]
    return title, poem


# ---------------------------------------------------------------------------
# Melody
# ---------------------------------------------------------------------------

def make_melody(a: dict, rng: random.Random) -> dict:
    scale_name = EMOTIONS[a["dominant"]]["scale"]
    scale = SCALES[scale_name]
    root = 55 + int(a["hue"] / 360 * 12)  # G3 .. F#4 depending on hue
    bpm = round(68 + a["energy"] * 84)
    beat = 60 / bpm

    words = a["words"][:40] or ["silence"]
    notes = []
    t = 0.0
    prev_degree = 0
    for w in words:
        val = sum(ord(c) for c in w)
        # move by small steps for a singable contour
        step = (val % 5) - 2
        degree = prev_degree + step
        degree = max(-2, min(len(scale) + 4, degree))
        prev_degree = degree
        octave, idx = divmod(degree, len(scale))
        pitch = root + 12 + octave * 12 + scale[idx]

        if len(w) <= 3:
            dur = 0.5
        elif len(w) <= 6:
            dur = 1.0
        else:
            dur = 1.5 if rng.random() < 0.6 else 2.0
        dur *= beat
        notes.append({"t": round(t, 3), "d": round(dur, 3), "p": pitch,
                      "name": f"{NOTE_NAMES[pitch % 12]}{pitch // 12 - 1}", "w": w})
        t += dur
        if t > 22:
            break

    total = t + 1.6
    return {
        "notes": notes,
        "bpm": bpm,
        "scale": scale_name,
        "key": NOTE_NAMES[root % 12],
        "root": root,
        "duration": round(total, 2),
    }


SAMPLE_RATE = 22050


def _midi_hz(p: int) -> float:
    return 440.0 * 2 ** ((p - 69) / 12)


def render_wav(melody: dict, energy: float) -> bytes:
    sr = SAMPLE_RATE
    n_total = int(melody["duration"] * sr)
    buf = array("f", bytes(4 * n_total))

    brightness = 0.25 + energy * 0.5
    two_pi = math.tau

    # Lead voice
    for n in melody["notes"]:
        f = _midi_hz(n["p"])
        start = int(n["t"] * sr)
        length = int((n["d"] + 0.7) * sr)
        decay = 2.2 / max(n["d"] + 0.4, 0.2)
        attack = int(0.012 * sr)
        k = two_pi * f / sr
        for i in range(length):
            j = start + i
            if j >= n_total:
                break
            env = (i / attack) if i < attack else math.exp(-decay * (i - attack) / sr)
            ph = k * i
            s = math.sin(ph) + brightness * 0.5 * math.sin(2 * ph) + brightness * 0.22 * math.sin(3 * ph)
            buf[j] += 0.32 * env * s

    # Soft pad: root + fifth drone, slow swell
    root_f = _midi_hz(melody["root"] - 12)
    fifth_f = root_f * 1.5
    kr, kf = two_pi * root_f / sr, two_pi * fifth_f / sr
    fade = sr * 1.2
    for i in range(0, n_total):
        env = min(1.0, i / fade, (n_total - i) / fade)
        buf[i] += 0.09 * env * (math.sin(kr * i) + 0.6 * math.sin(kf * i))

    # Echo
    delay = int(0.33 * sr)
    for i in range(delay, n_total):
        buf[i] += 0.3 * buf[i - delay]

    peak = max(1e-6, max(abs(min(buf)), abs(max(buf))))
    scale = 0.89 * 32767 / peak
    pcm = array("h", (int(s * scale) for s in buf))

    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return out.getvalue()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@lru_cache(maxsize=256)
def create(text: str) -> dict:
    text = text.strip()
    a = analyze(text)
    rng = random.Random(a["seed"])
    palette = make_palette(a, rng)
    svg, style = make_svg(a, palette, rng)
    title, poem = make_words(a, rng)
    melody = make_melody(a, rng)
    analysis = {k: v for k, v in a.items() if k != "words"}
    return {
        "title": title,
        "poem": poem,
        "palette": palette,
        "svg": svg,
        "style": style,
        "analysis": analysis,
        "melody": melody,
    }


@lru_cache(maxsize=64)
def audio_for(text: str) -> bytes:
    c = create(text)
    return render_wav(c["melody"], c["analysis"]["energy"])


if __name__ == "__main__":  # quick manual test
    import json
    demo = create("I dreamed the stars were singing over a quiet ocean")
    print(json.dumps({k: v for k, v in demo.items() if k != "svg"}, indent=2))
