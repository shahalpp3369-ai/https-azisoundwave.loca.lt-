"""
Synesthesia — a Python web app that lets you SEE, HEAR and READ your words.

This is a single-file Python application: all page layouts, styles and
browser behaviour are generated from Python strings inside this file, so
there are no separate templates/ or static/ folders.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000
"""

from __future__ import annotations

import io
import os
import secrets
import sqlite3
import uuid
import zipfile
from datetime import datetime, timezone

from flask import Flask, Response, abort, g, jsonify, render_template, request, send_from_directory
from jinja2 import DictLoader
from werkzeug.utils import secure_filename

import synth

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
if not os.path.isdir(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
DB_PATH = os.path.join(BASE_DIR, "synesthesia.db")
MAX_LEN = 400


# ===========================================================================
# Design system (styles) — generated from Python
# ===========================================================================

STYLE_CSS = r"""
/* ==========================================================================
   Synesthesia — design system
   ========================================================================== */
:root {
  --c0: #c084fc;
  --c1: #f0abfc;
  --c2: #818cf8;
  --c3: #fde68a;
  --c4: #6d28d9;
  --bg: #0b0816;
  --bg2: #1a1230;

  --text: #f4f1fb;
  --muted: rgba(244, 241, 251, 0.62);
  --glass: rgba(255, 255, 255, 0.055);
  --glass-strong: rgba(255, 255, 255, 0.09);
  --border: rgba(255, 255, 255, 0.11);
  --radius: 22px;
  --shadow: 0 30px 80px -30px rgba(0, 0, 0, 0.7);
  --ease: cubic-bezier(0.22, 1, 0.36, 1);

  --font-display: "Fraunces", Georgia, serif;
  --font-body: "Inter", system-ui, sans-serif;
}

*, *::before, *::after { box-sizing: border-box; }

html { scroll-behavior: smooth; }

body {
  margin: 0;
  min-height: 100vh;
  font-family: var(--font-body);
  color: var(--text);
  background: radial-gradient(1200px 800px at 70% -10%, var(--bg2), var(--bg) 60%);
  background-color: var(--bg);
  transition: background 1.2s var(--ease);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

a { color: inherit; }

.sr-only {
  position: absolute; width: 1px; height: 1px; overflow: hidden;
  clip: rect(0 0 0 0); white-space: nowrap;
}

/* ---------- Aurora background ---------- */
.aurora {
  position: fixed; inset: 0; z-index: -1; overflow: hidden; pointer-events: none;
  filter: blur(90px) saturate(1.2);
  opacity: 0.55;
}
.blob {
  position: absolute; border-radius: 50%;
  transition: background 1.4s var(--ease);
  animation: drift 26s ease-in-out infinite alternate;
}
.b1 { width: 46vw; height: 46vw; left: -10vw; top: -12vw; background: var(--c0); }
.b2 { width: 38vw; height: 38vw; right: -8vw; top: 18vh; background: var(--c2); animation-duration: 32s; animation-delay: -6s; }
.b3 { width: 34vw; height: 34vw; left: 30vw; bottom: -18vw; background: var(--c4); animation-duration: 38s; animation-delay: -12s; }

@keyframes drift {
  0%   { transform: translate(0, 0) scale(1); }
  50%  { transform: translate(6vw, 4vh) scale(1.12); }
  100% { transform: translate(-4vw, -3vh) scale(0.94); }
}

/* ---------- Nav ---------- */
.nav {
  position: sticky; top: 0; z-index: 10;
  display: flex; align-items: center; justify-content: space-between;
  padding: 18px clamp(18px, 5vw, 56px);
  backdrop-filter: blur(14px);
  background: linear-gradient(to bottom, rgba(8, 6, 18, 0.65), rgba(8, 6, 18, 0));
}
.brand {
  display: flex; align-items: center; gap: 10px;
  font-family: var(--font-display); font-size: 1.35rem; font-weight: 600;
  text-decoration: none; letter-spacing: 0.01em;
}
.brand-orb {
  width: 22px; height: 22px; border-radius: 50%;
  background: conic-gradient(from 0deg, var(--c0), var(--c1), var(--c2), var(--c3), var(--c0));
  box-shadow: 0 0 22px var(--c0);
  animation: spin 9s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

.nav nav { display: flex; gap: 6px; }
.nav nav a {
  text-decoration: none; padding: 8px 16px; border-radius: 999px;
  color: var(--muted); font-weight: 500; font-size: 0.95rem;
  transition: color 0.25s, background 0.25s;
}
.nav nav a:hover { color: var(--text); background: var(--glass); }
.nav nav a.active { color: var(--text); background: var(--glass-strong); border: 1px solid var(--border); }
.nav nav a.nav-download {
  color: var(--text);
  border: 1px solid transparent;
  background: linear-gradient(var(--glass-strong), var(--glass-strong)) padding-box,
              linear-gradient(120deg, var(--c0, #c084fc), var(--c2, #fbbf24)) border-box;
  transition: transform .2s ease, box-shadow .2s ease;
}
.nav nav a.nav-download:hover { transform: translateY(-1px); box-shadow: 0 6px 20px -8px var(--c0, #c084fc); }

main { width: min(1200px, 92vw); margin: 0 auto; padding-bottom: 60px; }

/* ---------- Hero ---------- */
.hero { text-align: center; padding: clamp(40px, 8vh, 90px) 0 34px; animation: rise 0.9s var(--ease) both; }
.hero.compact { padding-bottom: 20px; }
.eyebrow {
  text-transform: uppercase; letter-spacing: 0.22em; font-size: 0.74rem;
  color: var(--muted); margin: 0 0 14px; font-weight: 600;
}
h1 {
  font-family: var(--font-display); font-weight: 400;
  font-size: clamp(2.3rem, 6vw, 4.6rem); line-height: 1.04; margin: 0 auto 18px;
  max-width: 15ch; letter-spacing: -0.02em;
}
h1 em {
  font-style: italic;
  background: linear-gradient(100deg, var(--c3), var(--c0) 45%, var(--c2));
  -webkit-background-clip: text; background-clip: text; color: transparent;
}
.lede { color: var(--muted); max-width: 58ch; margin: 0 auto; line-height: 1.65; font-size: 1.05rem; }
.notice { margin-top: 18px; color: var(--c3); }

@keyframes rise { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: none; } }

/* ---------- Glass ---------- */
.glass {
  background: var(--glass);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  backdrop-filter: blur(18px) saturate(1.3);
  box-shadow: var(--shadow);
}

/* ---------- Composer ---------- */
.composer {
  max-width: 780px; margin: 0 auto 48px; padding: 18px;
  animation: rise 0.9s 0.12s var(--ease) both;
  transition: border-color 0.3s, box-shadow 0.3s;
}
.composer:focus-within { border-color: color-mix(in srgb, var(--c0) 60%, transparent); box-shadow: var(--shadow), 0 0 0 4px color-mix(in srgb, var(--c0) 18%, transparent); }
.composer textarea {
  width: 100%; resize: none; border: 0; outline: 0; background: transparent;
  color: var(--text); font-family: var(--font-display); font-size: clamp(1.15rem, 2.4vw, 1.5rem);
  line-height: 1.45; padding: 8px 10px;
}
.composer textarea::placeholder { color: rgba(244, 241, 251, 0.35); font-style: italic; }
.composer-bar { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 6px 4px 0; flex-wrap: wrap; }
.counter { color: var(--muted); font-size: 0.82rem; font-variant-numeric: tabular-nums; }
.composer-actions { display: flex; gap: 10px; }

/* ---------- Buttons ---------- */
.btn {
  position: relative; display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  border: 1px solid var(--border); border-radius: 999px; padding: 11px 20px;
  font: 600 0.95rem var(--font-body); color: var(--text); cursor: pointer; text-decoration: none;
  transition: transform 0.25s var(--ease), background 0.25s, box-shadow 0.25s, border-color 0.25s;
}
.btn:hover { transform: translateY(-2px); }
.btn:active { transform: translateY(0) scale(0.97); }
.btn.ghost { background: var(--glass); }
.btn.ghost:hover { background: var(--glass-strong); border-color: rgba(255, 255, 255, 0.22); }
.btn.primary {
  border: 0; color: #120a1f;
  background: linear-gradient(110deg, var(--c3), var(--c0) 55%, var(--c2));
  background-size: 200% 100%;
  box-shadow: 0 10px 30px -10px var(--c0);
  animation: shimmer 6s linear infinite;
}
.btn.primary:hover { box-shadow: 0 14px 40px -8px var(--c0); }
@keyframes shimmer { to { background-position: -200% 0; } }

.spinner {
  display: none; width: 16px; height: 16px; border-radius: 50%;
  border: 2px solid rgba(18, 10, 31, 0.3); border-top-color: #120a1f;
  animation: spin 0.7s linear infinite;
}
.btn.loading .spinner { display: inline-block; }
.btn.loading { pointer-events: none; opacity: 0.85; }

.like.liked { color: #ff8fb1; border-color: #ff8fb166; background: #ff8fb11a; }
.like.pop { animation: pop 0.45s var(--ease); }
@keyframes pop { 40% { transform: scale(1.18); } }

/* ---------- Result ---------- */
.result {
  display: grid; grid-template-columns: minmax(0, 1.05fr) minmax(0, 1fr); gap: 28px; align-items: start;
}
.result.reveal .art-col, .result.reveal .card { animation: rise 0.8s var(--ease) both; }
.result.reveal .card:nth-child(2) { animation-delay: 0.08s; }
.result.reveal .card:nth-child(3) { animation-delay: 0.16s; }
.result.reveal .card:nth-child(4) { animation-delay: 0.24s; }

.art-col { position: sticky; top: 90px; }
.art-frame { margin: 0; padding: 12px; overflow: hidden; }
.art {
  aspect-ratio: 1; border-radius: 14px; overflow: hidden;
  box-shadow: 0 20px 60px -20px var(--c0);
}
.art svg { width: 100%; height: 100%; display: block; }
.art.enter svg { animation: develop 1.4s var(--ease) both; }
@keyframes develop {
  from { opacity: 0; transform: scale(1.08); filter: blur(18px) saturate(0); }
  to { opacity: 1; transform: none; filter: none; }
}
.art-frame figcaption { display: flex; gap: 8px; padding: 12px 4px 2px; flex-wrap: wrap; }

.tag {
  display: inline-block; padding: 5px 12px; border-radius: 999px; font-size: 0.75rem; font-weight: 600;
  text-transform: capitalize; letter-spacing: 0.04em;
  background: color-mix(in srgb, var(--c0) 22%, transparent); border: 1px solid color-mix(in srgb, var(--c0) 40%, transparent);
}
.tag.subtle { background: var(--glass); border-color: var(--border); color: var(--muted); }

.actions { display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; }

.info-col { display: flex; flex-direction: column; gap: 18px; }
.card { padding: 22px 24px; }
.card h3 {
  margin: 0 0 14px; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.18em; color: var(--muted);
  display: flex; justify-content: space-between; align-items: baseline; gap: 10px;
}
.card h3 small { text-transform: none; letter-spacing: 0; font-weight: 400; font-size: 0.8rem; opacity: 0.8; }

.title { font-family: var(--font-display); font-weight: 600; font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin: 0 0 14px; line-height: 1.1; }
.poem {
  margin: 0; padding-left: 16px; border-left: 2px solid var(--c0);
  font-family: var(--font-display); font-style: italic; font-size: 1.2rem; line-height: 1.7; color: rgba(244, 241, 251, 0.9);
}
.poem span { display: block; opacity: 0; transform: translateX(-8px); animation: line-in 0.7s var(--ease) forwards; }
@keyframes line-in { to { opacity: 1; transform: none; } }

/* Palette */
.palette { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
.swatch {
  border: 0; cursor: pointer; border-radius: 14px; height: 92px; padding: 8px; position: relative;
  display: flex; align-items: flex-end; justify-content: center;
  font: 600 0.72rem var(--font-body); letter-spacing: 0.05em; text-transform: uppercase;
  transition: transform 0.3s var(--ease), box-shadow 0.3s;
  opacity: 0; animation: rise 0.6s var(--ease) forwards;
}
.swatch:hover { transform: translateY(-6px) scale(1.04); box-shadow: 0 16px 30px -12px currentColor; }
.swatch span { background: rgba(0, 0, 0, 0.35); color: #fff; padding: 3px 7px; border-radius: 6px; backdrop-filter: blur(4px); }

/* Player */
.player { display: flex; align-items: center; gap: 14px; }
.play {
  flex: none; width: 56px; height: 56px; border-radius: 50%; border: 0; cursor: pointer;
  background: linear-gradient(135deg, var(--c3), var(--c0)); color: #120a1f;
  display: grid; place-items: center; box-shadow: 0 10px 28px -8px var(--c0);
  transition: transform 0.25s var(--ease);
}
.play:hover { transform: scale(1.08); }
.play svg { width: 24px; height: 24px; fill: currentColor; }
.play .icon-pause { display: none; }
.play.playing .icon-play { display: none; }
.play.playing .icon-pause { display: block; }
.play.loading { animation: pulse 1s ease-in-out infinite; }
@keyframes pulse { 50% { transform: scale(0.92); opacity: 0.7; } }
.roll { flex: 1; width: 100%; min-width: 0; height: 110px; border-radius: 12px; background: rgba(0, 0, 0, 0.25); }
.lyric {
  margin: 14px 0 0; min-height: 1.6em; text-align: center; font-family: var(--font-display);
  font-size: 1.15rem; color: var(--muted); transition: color 0.2s;
}
.lyric b { color: var(--text); font-weight: 600; text-shadow: 0 0 18px var(--c0); }

/* Meters */
.meters { display: flex; flex-direction: column; gap: 10px; }
.meter { display: grid; grid-template-columns: 96px 1fr 44px; align-items: center; gap: 12px; font-size: 0.88rem; text-transform: capitalize; }
.meter-track { height: 8px; border-radius: 99px; background: rgba(255, 255, 255, 0.08); overflow: hidden; }
.meter-fill { height: 100%; width: 0; border-radius: 99px; transition: width 1.1s var(--ease); }
.meter em { font-style: normal; color: var(--muted); text-align: right; font-variant-numeric: tabular-nums; }

.stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 18px; }
.stats div { background: rgba(255, 255, 255, 0.04); border: 1px solid var(--border); border-radius: 14px; padding: 10px 12px; }
.stats span { display: block; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.14em; color: var(--muted); }
.stats strong { font-size: 1.15rem; font-variant-numeric: tabular-nums; }

.echo { margin: 18px 0 0; line-height: 1.7; color: var(--muted); font-size: 0.95rem; }
.echo mark { background: color-mix(in srgb, var(--c0) 30%, transparent); color: var(--text); padding: 1px 5px; border-radius: 6px; }

/* ---------- Gallery ---------- */
.filters { display: flex; justify-content: space-between; gap: 14px; flex-wrap: wrap; margin-bottom: 26px; }
.chips { display: flex; gap: 8px; flex-wrap: wrap; }
.chip {
  text-decoration: none; padding: 7px 14px; border-radius: 999px; font-size: 0.85rem; text-transform: capitalize;
  background: var(--glass); border: 1px solid var(--border); color: var(--muted); transition: all 0.25s var(--ease);
}
.chip:hover { color: var(--text); transform: translateY(-2px); }
.chip.active { color: #120a1f; background: var(--text); border-color: var(--text); }

.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
.tile {
  text-decoration: none; overflow: hidden; display: flex; flex-direction: column;
  transition: transform 0.4s var(--ease), box-shadow 0.4s, border-color 0.4s;
  opacity: 0; animation: rise 0.7s var(--ease) forwards; animation-delay: calc(var(--i) * 45ms);
}
.tile:hover { transform: translateY(-8px) rotate(-0.4deg); border-color: rgba(255, 255, 255, 0.25); }
.tile-art { aspect-ratio: 1; overflow: hidden; }
.tile-art svg { width: 100%; height: 100%; display: block; transition: transform 0.8s var(--ease); }
.tile:hover .tile-art svg { transform: scale(1.07); }
.tile-body { padding: 14px 16px 16px; display: flex; flex-direction: column; gap: 8px; flex: 1; }
.tile-body h2 { font-family: var(--font-display); font-weight: 600; font-size: 1.25rem; margin: 0; }
.tile-body p { margin: 0; color: var(--muted); font-size: 0.86rem; line-height: 1.5; flex: 1; }
.tile-swatches { display: flex; height: 6px; border-radius: 99px; overflow: hidden; }
.tile-swatches span { flex: 1; }
.tile-meta { display: flex; justify-content: space-between; align-items: center; font-size: 0.85rem; color: var(--muted); }

.mood-joy { --m: #fbbf24; } .mood-love { --m: #fb7185; } .mood-calm { --m: #22d3ee; } .mood-wonder { --m: #a78bfa; }
.mood-nature { --m: #4ade80; } .mood-melancholy { --m: #60a5fa; } .mood-anger { --m: #f87171; } .mood-fear { --m: #818cf8; }
.tag[class*="mood-"] { background: color-mix(in srgb, var(--m) 20%, transparent); border-color: color-mix(in srgb, var(--m) 45%, transparent); color: var(--m); }
.chip[class*="mood-"]:not(.active)::before { content: ""; display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: var(--m); margin-right: 7px; }

.empty { padding: 50px; text-align: center; color: var(--muted); }
.empty a { color: var(--text); }

/* ---------- Footer & toast ---------- */
.footer { text-align: center; color: var(--muted); font-size: 0.82rem; padding: 30px 20px 40px; }

.toast {
  position: fixed; left: 50%; bottom: 28px; transform: translate(-50%, 30px);
  background: rgba(20, 14, 36, 0.9); border: 1px solid var(--border); backdrop-filter: blur(12px);
  padding: 12px 20px; border-radius: 999px; font-size: 0.9rem; opacity: 0; pointer-events: none;
  transition: all 0.4s var(--ease); z-index: 50; display: flex; align-items: center; gap: 10px;
}
.toast.show { opacity: 1; transform: translate(-50%, 0); }
.toast i { width: 14px; height: 14px; border-radius: 4px; display: inline-block; }

/* ---------- Responsive ---------- */
@media (max-width: 900px) {
  .result { grid-template-columns: 1fr; }
  .art-col { position: static; }
}
@media (max-width: 520px) {
  .palette { grid-template-columns: repeat(5, 1fr); gap: 6px; }
  .swatch { height: 70px; font-size: 0.6rem; }
  .meter { grid-template-columns: 80px 1fr 38px; }
  .composer-actions { width: 100%; }
  .composer-actions .btn { flex: 1; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; }
}
"""


# ===========================================================================
# Browser behaviour — generated from Python
# ===========================================================================

APP_JS = r"""
/* Synesthesia front-end: renders creations returned by the Python engine. */
(() => {
  const $ = (id) => document.getElementById(id);
  const els = {
    prompt: $("prompt"), counter: $("counter"), create: $("create-btn"), inspire: $("inspire-btn"),
    result: $("result"), art: $("art"), styleTag: $("style-tag"), schemeTag: $("scheme-tag"),
    title: $("title"), poem: $("poem"), mood: $("mood-line"), palette: $("palette"),
    emotions: $("emotions"), valence: $("stat-valence"), energy: $("stat-energy"), hue: $("stat-hue"),
    echo: $("echo"), play: $("play-btn"), roll: $("roll"), lyric: $("lyric"), audio: $("audio"),
    meta: $("melody-meta"), download: $("download-btn"), downloadJpg: $("download-jpg-btn"), share: $("share-btn"),
    like: $("like-btn"), likeCount: $("like-count"), toast: $("toast"),
  };

  const MOOD_COLORS = {
    joy: "#fbbf24", love: "#fb7185", calm: "#22d3ee", wonder: "#a78bfa",
    nature: "#4ade80", melancholy: "#60a5fa", anger: "#f87171", fear: "#818cf8",
  };
  const STYLE_NAMES = {
    bloom: "Bloom", flow: "Flow field", waves: "Tidal layers", orbits: "Orbital system",
    rain: "Rainfall", shards: "Shattered glass",
  };
  const INSPIRATIONS = [
    "I dreamed the stars were singing over a quiet ocean",
    "Golden summer afternoons, laughing until the sun went down",
    "The forest remembers every footstep on its mossy path",
    "Rain on the window and a letter I never sent",
    "Thunder in my chest, a storm that refuses to break!",
    "Your heart beside mine, forever and a little longer",
    "Lost in the dark corridor, shadows whispering my name",
    "Morning tea, soft clouds, nowhere to be",
    "What lies beyond the last galaxy?",
    "Wild roots climbing toward the spring light",
    "Dancing barefoot at the festival of lanterns",
    "Cold November streets full of faded memories",
  ];

  let current = null;
  let liked = new Set(JSON.parse(localStorage.getItem("syn-liked") || "[]"));
  let rafId = null;

  /* ---------------- utilities ---------------- */
  const toast = (msg, color) => {
    els.toast.innerHTML = (color ? `<i style="background:${color}"></i>` : "") + msg;
    els.toast.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => els.toast.classList.remove("show"), 2200);
  };
  const escapeHtml = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const luminance = (hex) => {
    const n = parseInt(hex.slice(1), 16);
    const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  };

  const applyTheme = (p) => {
    const root = document.documentElement.style;
    p.colors.forEach((c, i) => root.setProperty(`--c${i}`, c));
    root.setProperty("--bg", p.background);
    root.setProperty("--bg2", p.background2);
  };

  /* ---------------- composer ---------------- */
  const updateCounter = () => { els.counter.textContent = `${els.prompt.value.length} / 400`; };
  els.prompt.addEventListener("input", updateCounter);
  els.prompt.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey || !e.shiftKey)) { e.preventDefault(); create(); }
  });

  let inspireIdx = Math.floor(Math.random() * INSPIRATIONS.length);
  els.inspire.addEventListener("click", () => {
    const text = INSPIRATIONS[inspireIdx++ % INSPIRATIONS.length];
    els.prompt.value = "";
    let i = 0;
    clearInterval(els.inspire._t);
    els.inspire._t = setInterval(() => {
      els.prompt.value = text.slice(0, ++i);
      updateCounter();
      if (i >= text.length) { clearInterval(els.inspire._t); els.prompt.focus(); }
    }, 22);
  });

  els.create.addEventListener("click", create);

  async function create() {
    const text = els.prompt.value.trim();
    if (!text) { toast("Write something first — a feeling, a memory, a dream."); els.prompt.focus(); return; }
    els.create.classList.add("loading");
    try {
      const res = await fetch("/api/create", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");
      render(data);
      history.pushState({ id: data.id }, "", data.share_url);
      els.result.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (err) {
      toast(err.message);
    } finally {
      els.create.classList.remove("loading");
    }
  }

  async function load(id) {
    const res = await fetch(`/api/creation/${id}`);
    if (!res.ok) return;
    const data = await res.json();
    els.prompt.value = data.text;
    updateCounter();
    render(data);
  }

  /* ---------------- render ---------------- */
  function render(d) {
    current = d;
    stopAudio();
    applyTheme(d.palette);
    document.title = `${d.title} · Synesthesia`;

    els.result.hidden = false;
    els.result.classList.remove("reveal"); void els.result.offsetWidth; els.result.classList.add("reveal");

    // Art
    els.art.classList.remove("enter");
    els.art.innerHTML = d.svg;
    void els.art.offsetWidth; els.art.classList.add("enter");
    els.styleTag.textContent = STYLE_NAMES[d.style] || d.style;
    els.schemeTag.textContent = `${d.palette.scheme} palette`;
    els.download.href = `/download/${d.id}.svg`;

    // Words
    const a = d.analysis;
    els.mood.textContent = `Dominant mood · ${a.dominant}`;
    els.title.textContent = d.title;
    els.poem.innerHTML = d.poem.map((line, i) => `<span style="animation-delay:${0.3 + i * 0.45}s">${escapeHtml(line)}</span>`).join("");

    // Palette
    els.palette.innerHTML = "";
    d.palette.colors.forEach((c, i) => {
      const b = document.createElement("button");
      b.className = "swatch"; b.type = "button"; b.id = `swatch-${i}`;
      b.style.background = c; b.style.color = c; b.style.animationDelay = `${i * 70}ms`;
      b.innerHTML = `<span>${c}</span>`;
      b.title = `Copy ${c}`;
      b.addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(c); toast(`Copied ${c}`, c); } catch { toast(c, c); }
      });
      els.palette.appendChild(b);
    });

    // Emotions
    els.emotions.innerHTML = a.emotions.map((e) => `
      <div class="meter"><span>${e.name}</span>
        <div class="meter-track"><div class="meter-fill" data-w="${Math.round(e.weight * 100)}" style="background:linear-gradient(90deg, ${MOOD_COLORS[e.name]}88, ${MOOD_COLORS[e.name]})"></div></div>
        <em>${Math.round(e.weight * 100)}%</em></div>`).join("");
    requestAnimationFrame(() => requestAnimationFrame(() => {
      els.emotions.querySelectorAll(".meter-fill").forEach((f) => { f.style.width = f.dataset.w + "%"; });
    }));
    els.valence.textContent = (a.valence > 0 ? "+" : "") + a.valence.toFixed(2);
    els.energy.textContent = Math.round(a.energy * 100) + "%";
    els.hue.textContent = Math.round(a.hue) + "°";

    const matched = new Set(a.matched);
    els.echo.innerHTML = matched.size
      ? "Words that shaped it: " + escapeHtml(d.text).replace(/[A-Za-z']+/g, (w) => (matched.has(w.toLowerCase()) ? `<mark>${w}</mark>` : w))
      : "No familiar emotion words — so the text's own fingerprint chose this mood.";

    // Melody
    const m = d.melody;
    els.meta.textContent = `${m.key} ${m.scale} · ${m.bpm} bpm · ${m.notes.length} notes`;
    els.lyric.textContent = "Press play to hear your words sing.";
    els.audio.src = "";
    els.audio.removeAttribute("src");
    drawRoll(-1);

    // Like
    els.likeCount.textContent = d.likes;
    els.like.classList.toggle("liked", liked.has(d.id));
  }

  /* ---------------- piano roll ---------------- */
  function drawRoll(time) {
    if (!current) return;
    const cv = els.roll, ctx = cv.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const w = cv.clientWidth, h = cv.clientHeight;
    if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const { notes, duration } = current.melody;
    const colors = current.palette.colors;
    const pitches = notes.map((n) => n.p);
    const lo = Math.min(...pitches) - 2, hi = Math.max(...pitches) + 2;
    const pad = 8;
    const x = (t) => pad + (t / duration) * (w - pad * 2);
    const y = (p) => h - pad - ((p - lo) / (hi - lo || 1)) * (h - pad * 2);

    // grid
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    for (let p = lo; p <= hi; p++) { ctx.beginPath(); ctx.moveTo(0, y(p)); ctx.lineTo(w, y(p)); ctx.stroke(); }

    let active = null;
    notes.forEach((n, i) => {
      const nx = x(n.t), nw = Math.max(3, x(n.t + n.d) - nx - 2), ny = y(n.p) - 4;
      const on = time >= n.t && time < n.t + n.d;
      if (on) active = n;
      ctx.fillStyle = colors[i % colors.length];
      ctx.globalAlpha = time < 0 ? 0.85 : on ? 1 : time > n.t ? 0.55 : 0.3;
      ctx.shadowColor = colors[i % colors.length];
      ctx.shadowBlur = on ? 18 : 0;
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(nx, ny, nw, 8, 4) : ctx.rect(nx, ny, nw, 8);
      ctx.fill();
    });
    ctx.globalAlpha = 1; ctx.shadowBlur = 0;

    if (time >= 0) {
      ctx.strokeStyle = "rgba(255,255,255,0.85)"; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x(time), 0); ctx.lineTo(x(time), h); ctx.stroke(); ctx.lineWidth = 1;
    }
    return active;
  }

  function tick() {
    const active = drawRoll(els.audio.currentTime);
    if (active && els.lyric.dataset.word !== active.w + active.t) {
      els.lyric.dataset.word = active.w + active.t;
      els.lyric.innerHTML = `<b>${escapeHtml(active.w)}</b> &nbsp;·&nbsp; ${active.name}`;
    }
    rafId = requestAnimationFrame(tick);
  }

  function stopAudio() {
    els.audio.pause();
    cancelAnimationFrame(rafId);
    els.play.classList.remove("playing", "loading");
  }

  els.play.addEventListener("click", async () => {
    if (!current) return;
    if (!els.audio.paused) { stopAudio(); drawRoll(els.audio.currentTime); return; }
    if (!els.audio.getAttribute("src")) {
      els.play.classList.add("loading");
      els.audio.src = current.audio_url;
    }
    try {
      await els.audio.play();
      els.play.classList.remove("loading");
      els.play.classList.add("playing");
      tick();
    } catch {
      els.play.classList.remove("loading");
      toast("Couldn't play audio");
    }
  });
  els.audio.addEventListener("ended", () => {
    stopAudio(); els.audio.currentTime = 0; drawRoll(-1);
    els.lyric.textContent = "Play again?";
  });
  els.roll.addEventListener("click", (e) => {
    if (!current || !els.audio.getAttribute("src")) return;
    const r = els.roll.getBoundingClientRect();
    els.audio.currentTime = ((e.clientX - r.left) / r.width) * current.melody.duration;
    drawRoll(els.audio.currentTime);
  });
  window.addEventListener("resize", () => drawRoll(els.audio.paused ? -1 : els.audio.currentTime));

  /* ---------------- JPG export (client-side) ---------------- */
  els.downloadJpg.addEventListener("click", () => {
    if (!current) return;
    let svg = current.svg;
    if (!/xmlns=/.test(svg)) svg = svg.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
    const svgEl = els.art.querySelector("svg");
    const vb = svgEl && svgEl.viewBox && svgEl.viewBox.baseVal;
    const baseW = (vb && vb.width) || (svgEl && svgEl.clientWidth) || 800;
    const baseH = (vb && vb.height) || (svgEl && svgEl.clientHeight) || 800;
    const scale = Math.max(1, 1600 / baseW); // export at ~1600px wide
    const img = new Image();
    img.onload = () => {
      const cv = document.createElement("canvas");
      cv.width = Math.round(baseW * scale);
      cv.height = Math.round(baseH * scale);
      const ctx = cv.getContext("2d");
      ctx.fillStyle = current.palette.background || "#000"; // JPG has no transparency
      ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      cv.toBlob((blob) => {
        if (!blob) { toast("Couldn't create JPG"); return; }
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = current.title.toLowerCase().replace(/[^a-z0-9]+/g, "-") + ".jpg";
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        toast("JPG downloaded");
      }, "image/jpeg", 0.92);
    };
    img.onerror = () => toast("Couldn't render JPG");
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  });

  /* ---------------- share & like ---------------- */
  els.share.addEventListener("click", async () => {
    if (!current) return;
    const url = location.origin + current.share_url;
    try { await navigator.clipboard.writeText(url); toast("Link copied — send it to someone"); } catch { toast(url); }
  });

  els.like.addEventListener("click", async () => {
    if (!current) return;
    if (liked.has(current.id)) { toast("You already love this one ♥"); return; }
    const res = await fetch(`/api/like/${current.id}`, { method: "POST" });
    if (!res.ok) return;
    const { likes } = await res.json();
    liked.add(current.id);
    localStorage.setItem("syn-liked", JSON.stringify([...liked]));
    els.likeCount.textContent = likes;
    els.like.classList.add("liked", "pop");
    setTimeout(() => els.like.classList.remove("pop"), 500);
  });

  window.addEventListener("popstate", (e) => { if (e.state && e.state.id) load(e.state.id); });

  if (window.PRELOAD_ID) {
    history.replaceState({ id: window.PRELOAD_ID }, "", location.pathname);
    load(window.PRELOAD_ID);
  }
})();
"""


# ===========================================================================
# Page layouts — generated from Python (loaded via Jinja DictLoader)
# ===========================================================================

BASE_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{% block title %}Synesthesia — See, Hear & Read Your Words{% endblock %}</title>
  <meta name="description" content="{% block description %}Synesthesia turns any sentence into a unique color palette, generative artwork, poem and melody — powered by Python.{% endblock %}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,400&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/style.css">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='40' fill='%23c084fc'/><circle cx='62' cy='42' r='22' fill='%23fbbf24'/></svg>">
</head>
<body>
  <div class="aurora" aria-hidden="true">
    <span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span>
  </div>

  <header class="nav">
    <a href="/" class="brand" id="brand-link">
      <span class="brand-orb"></span>
      Synesthesia
    </a>
    <nav>
      <a href="/" id="nav-create" class="{% if request.path == '/' or request.path.startswith('/c/') %}active{% endif %}">Create</a>
      <a href="/gallery" id="nav-gallery" class="{% if request.path.startswith('/gallery') %}active{% endif %}">Gallery</a>

    </nav>
  </header>

  <main>
    {% block content %}{% endblock %}
  </main>

  <footer class="footer">
    Every creation is generated deterministically by Python from your words — same words, same world.
  </footer>

  <div id="toast" class="toast" role="status" aria-live="polite"></div>
  {% block scripts %}{% endblock %}
</body>
</html>
"""

INDEX_PAGE = r"""{% extends "base.html" %}

{% block title %}{% if preload_title %}{{ preload_title }} · Synesthesia{% else %}Synesthesia — See, Hear & Read Your
Words{% endif %}{% endblock %}

{% block content %}
<section class="hero">
  <p class="eyebrow">A Python-powered synesthetic machine</p>
  <h1>Turn your words into <em>colour, sound</em> &amp; verse</h1>
  <p class="lede">Type a feeling, a memory or a dream. Synesthesia reads its emotion and paints an artwork,
    mixes a palette, writes a poem and composes a melody — uniquely yours.</p>
  {% if not_found %}<p class="notice">That creation drifted away. Make a new one?</p>{% endif %}
</section>

<section class="composer glass" aria-label="Write your text">
  <label for="prompt" class="sr-only">Your words</label>
  <textarea id="prompt" maxlength="400" rows="3"
    placeholder="e.g. I dreamed the stars were singing over a quiet ocean…"></textarea>
  <div class="composer-bar">
    <span id="counter" class="counter">0 / 400</span>
    <div class="composer-actions">
      <button type="button" id="inspire-btn" class="btn ghost">✦ Inspire me</button>
      <button type="button" id="create-btn" class="btn primary">
        <span class="btn-label">Transmute</span>
        <span class="spinner" aria-hidden="true"></span>
      </button>
    </div>
  </div>
</section>

<section id="result" class="result" hidden aria-live="polite">
  <div class="art-col">
    <figure class="art-frame glass">
      <div id="art" class="art"></div>
      <figcaption>
        <span id="style-tag" class="tag"></span>
        <span id="scheme-tag" class="tag subtle"></span>
      </figcaption>
    </figure>
    <div class="actions">
      <a id="download-btn" class="btn ghost" href="#" download>⤓ Download SVG</a>
      <button type="button" id="download-jpg-btn" class="btn ghost">⤓ Download JPG</button>
      <button type="button" id="share-btn" class="btn ghost">⧉ Copy link</button>
      <button type="button" id="like-btn" class="btn ghost like">♥ <span id="like-count">0</span></button>
    </div>
  </div>

  <div class="info-col">
    <article class="card glass">
      <p class="eyebrow" id="mood-line"></p>
      <h2 id="title" class="title"></h2>
      <blockquote id="poem" class="poem"></blockquote>
    </article>

    <article class="card glass">
      <h3>Palette <small>click to copy</small></h3>
      <div id="palette" class="palette"></div>
    </article>

    <article class="card glass">
      <h3>Melody <small id="melody-meta"></small></h3>
      <div class="player">
        <button type="button" id="play-btn" class="play" aria-label="Play melody">
          <svg viewBox="0 0 24 24" class="icon-play">
            <path d="M8 5v14l11-7z" />
          </svg>
          <svg viewBox="0 0 24 24" class="icon-pause">
            <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
          </svg>
        </button>
        <canvas id="roll" class="roll" width="640" height="140" aria-label="Piano roll visualisation"></canvas>
      </div>
      <p id="lyric" class="lyric">Press play to hear your words sing.</p>
      <audio id="audio" preload="none"></audio>
    </article>

    <article class="card glass">
      <h3>Emotional fingerprint</h3>
      <div id="emotions" class="meters"></div>
      <div class="stats">
        <div><span>Valence</span><strong id="stat-valence"></strong></div>
        <div><span>Energy</span><strong id="stat-energy"></strong></div>
        <div><span>Hue</span><strong id="stat-hue"></strong></div>
      </div>
      <p id="echo" class="echo"></p>
    </article>
  </div>
</section>
{% endblock %}

{% block scripts %}
<script>window.PRELOAD_ID = {{ preload_id | tojson }};</script>
<script src="/assets/app.js"></script>
{% endblock %}
"""

GALLERY_PAGE = r"""{% extends "base.html" %}

{% block title %}Gallery · Synesthesia{% endblock %}
{% block description %}Browse colour palettes, artworks, poems and melodies that other people have created from their words.{% endblock %}

{% block content %}
<section class="hero compact">
  <p class="eyebrow">{{ total }} creation{{ '' if total == 1 else 's' }} so far</p>
  <h1>The <em>Gallery</em></h1>
  <p class="lede">Every tile below began as a sentence. Click one to hear it.</p>
</section>

<section class="filters" aria-label="Filter gallery">
  <div class="chips">
    <a id="mood-all" class="chip {% if not mood %}active{% endif %}" href="/gallery?sort={{ sort }}">All</a>
    {% for m in moods %}
      <a id="mood-{{ m }}" class="chip mood-{{ m }} {% if mood == m %}active{% endif %}" href="/gallery?sort={{ sort }}&mood={{ m }}">{{ m }}</a>
    {% endfor %}
  </div>
  <div class="chips">
    <a id="sort-new" class="chip {% if sort != 'top' %}active{% endif %}" href="/gallery?sort=new{% if mood %}&mood={{ mood }}{% endif %}">Newest</a>
    <a id="sort-top" class="chip {% if sort == 'top' %}active{% endif %}" href="/gallery?sort=top{% if mood %}&mood={{ mood }}{% endif %}">Most loved</a>
  </div>
</section>

{% if items %}
<section class="grid">
  {% for it in items %}
  <a class="tile glass" href="/c/{{ it.row.id }}" id="tile-{{ it.row.id }}" style="--i: {{ loop.index0 }}">
    <div class="tile-art">{{ it.svg|safe }}</div>
    <div class="tile-body">
      <div class="tile-swatches">
        {% for c in it.colors %}<span style="background: {{ c }}"></span>{% endfor %}
      </div>
      <h2>{{ it.title }}</h2>
      <p>“{{ it.row.text[:90] }}{% if it.row.text|length > 90 %}…{% endif %}”</p>
      <div class="tile-meta">
        <span class="tag mood-{{ it.row.dominant }}">{{ it.row.dominant }}</span>
        <span>♥ {{ it.row.likes }}</span>
      </div>
    </div>
  </a>
  {% endfor %}
</section>
{% else %}
<section class="empty glass">
  <p>Nothing here yet. <a href="/">Be the first to create something →</a></p>
</section>
{% endif %}
{% endblock %}
"""

ABOUT_PAGE = r"""{% extends "base.html" %}
{% block title %}About – Synesthesia{% endblock %}
{% block content %}
<h1>About Synesthesia</h1>
<p>This application turns your words into sound, visual art, and more. It was created as a playful exploration of multimodal AI.</p>
{% endblock %}
"""

STATS_PAGE = r"""{% extends "base.html" %}
{% block title %}Stats – Synesthesia{% endblock %}
{% block content %}
<h1>Application Statistics</h1>
<p>Total creations: {{ total }}</p>
<p>Total likes: {{ likes_sum }}</p>
{% endblock %}
"""

PAGES = {
    "base.html": BASE_PAGE,
    "index.html": INDEX_PAGE,
    "gallery.html": GALLERY_PAGE,
    "about.html": ABOUT_PAGE,
    "stats.html": STATS_PAGE,
}


# ===========================================================================
# App setup — pages come from Python strings, not from template files
# ===========================================================================

app = Flask(__name__, static_folder=None, template_folder=None)
app.jinja_loader = DictLoader(PAGES)


@app.get("/assets/style.css")
def asset_css():
    return Response(STYLE_CSS, mimetype="text/css", headers={"Cache-Control": "public, max-age=3600"})


@app.get("/assets/app.js")
def asset_js():
    return Response(APP_JS, mimetype="application/javascript", headers={"Cache-Control": "public, max-age=3600"})


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            """CREATE TABLE IF NOT EXISTS creations (
                   id TEXT PRIMARY KEY,
                   text TEXT NOT NULL UNIQUE,
                   title TEXT NOT NULL,
                   dominant TEXT NOT NULL,
                   likes INTEGER NOT NULL DEFAULT 0,
                   created_at TEXT NOT NULL
               )"""
        )


def row_to_payload(row: sqlite3.Row) -> dict:
    data = synth.create(row["text"])
    return {
        "id": row["id"],
        "text": row["text"],
        "likes": row["likes"],
        "created_at": row["created_at"],
        "audio_url": f"/audio/{row['id']}.wav",
        "share_url": f"/c/{row['id']}",
        **data,
    }


def find(cid: str) -> sqlite3.Row:
    row = get_db().execute("SELECT * FROM creations WHERE id = ?", (cid,)).fetchone()
    if row is None:
        abort(404)
    return row


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html", preload_id=None)


@app.route("/c/<cid>")
def shared(cid: str):
    row = find(cid)
    return render_template("index.html", preload_id=row["id"], preload_title=row["title"])


@app.route("/gallery")
def gallery():
    sort = request.args.get("sort", "new")
    order = "likes DESC, created_at DESC" if sort == "top" else "created_at DESC"
    mood = request.args.get("mood")
    db = get_db()
    if mood in synth.EMOTIONS:
        rows = db.execute(f"SELECT * FROM creations WHERE dominant = ? ORDER BY {order} LIMIT 60", (mood,)).fetchall()
    else:
        mood = None
        rows = db.execute(f"SELECT * FROM creations ORDER BY {order} LIMIT 60").fetchall()
    items = []
    for r in rows:
        c = synth.create(r["text"])
        items.append({"row": r, "svg": c["svg"], "colors": c["palette"]["colors"], "title": c["title"]})
    total = db.execute("SELECT COUNT(*) FROM creations").fetchone()[0]
    return render_template(
        "gallery.html", items=items, sort=sort, mood=mood, moods=synth.EMOTION_NAMES, total=total
    )


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

@app.post("/api/create")
def api_create():
    payload = request.get_json(silent=True) or {}
    text = " ".join(str(payload.get("text", "")).split())[:MAX_LEN]
    if not text:
        return jsonify(error="Write something first — a feeling, a memory, a dream."), 400

    db = get_db()
    row = db.execute("SELECT * FROM creations WHERE text = ?", (text,)).fetchone()
    if row is None:
        data = synth.create(text)
        cid = secrets.token_urlsafe(6)
        db.execute(
            "INSERT INTO creations (id, text, title, dominant, created_at) VALUES (?, ?, ?, ?, ?)",
            (cid, text, data["title"], data["analysis"]["dominant"], datetime.now(timezone.utc).isoformat()),
        )
        db.commit()
        row = find(cid)
    return jsonify(row_to_payload(row))


@app.get("/api/creation/<cid>")
def api_get(cid: str):
    return jsonify(row_to_payload(find(cid)))


@app.post("/api/like/<cid>")
def api_like(cid: str):
    db = get_db()
    find(cid)
    db.execute("UPDATE creations SET likes = likes + 1 WHERE id = ?", (cid,))
    db.commit()
    return jsonify(likes=find(cid)["likes"])


@app.get("/audio/<cid>.wav")
def audio(cid: str):
    wav = synth.audio_for(find(cid)["text"])
    return Response(wav, mimetype="audio/wav", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/download/<cid>.svg")
def download_svg(cid: str):
    row = find(cid)
    svg = synth.create(row["text"])["svg"]
    filename = "".join(ch if ch.isalnum() else "-" for ch in row["title"].lower())
    return Response(
        svg,
        mimetype="image/svg+xml",
        headers={"Content-Disposition": f'attachment; filename="{filename}.svg"'},
    )


SOURCE_FILES = ["app.py", "synth.py", "requirements.txt", "README.md", "py.ipynb"]


@app.get("/download/source.zip")
def download_source():
    """Bundle the app's source code into a ZIP (extracts to a 'synesthesia/' folder)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in SOURCE_FILES:
            path = os.path.join(BASE_DIR, name)
            if os.path.isfile(path):
                zf.write(path, f"synesthesia/{name}")
    buf.seek(0)
    return Response(
        buf.getvalue(),
        mimetype="application/zip",
        headers={"Content-Disposition": 'attachment; filename="synesthesia-source.zip"'},
    )


@app.errorhandler(404)
def not_found(_e):
    if request.path.startswith("/api/"):
        return jsonify(error="Not found"), 404
    return render_template("index.html", preload_id=None, not_found=True), 404


init_db()

# ---------------------------------------------------------------------------
# New Pages
# ---------------------------------------------------------------------------

@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/stats")
def stats():
    # Simple stats page showing total creations and likes sum
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM creations").fetchone()[0]
    likes_sum = db.execute("SELECT SUM(likes) FROM creations").fetchone()[0] or 0
    return render_template("stats.html", total=total, likes_sum=likes_sum)


# ---------------------------------------------------------------------------
# API Upload Endpoint
# ---------------------------------------------------------------------------

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.post("/api/upload")
def api_upload():
    if "file" not in request.files:
        return jsonify(error="No file part"), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify(error="No selected file"), 400
    if not allowed_file(file.filename):
        return jsonify(error="File type not allowed"), 400
    filename = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{filename}"
    filepath = os.path.join(UPLOAD_FOLDER, unique_name)
    file.save(filepath)
    return jsonify(url=f"/uploads/{unique_name}")


# Serve uploaded files
@app.get("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
