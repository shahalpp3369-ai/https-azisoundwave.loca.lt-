# ◐ Synesthesia

**See, hear and read your words.** A Python (Flask) web app that turns any sentence into:

- 🎨 **A generative artwork** (SVG) – 6 styles: bloom, flow field, tidal waves, orbital system, rainfall, shattered glass
- 🌈 **A colour palette** – click any swatch to copy its hex; the whole website re-themes to it
- ✍️ **A title and a 3-line poem** that weaves in one of your own words
- 🎵 **A melody** synthesised in pure Python (WAV), with a live piano roll and karaoke-style word highlighting
- 🧠 **An emotional fingerprint** – valence, energy, hue and the words that shaped it

Everything is **deterministic**: the same words always give the same creation. Creations are saved to SQLite, can be shared by link, liked, and browsed in the **Gallery** (filter by mood, sort by most loved).

## Run it

```powershell
pip install -r requirements.txt
python app.py
```

Open <http://127.0.0.1:5000>.

## Files

| File | What it does |
|------|--------------|
| `synth.py` | The engine: emotion analysis, palette, SVG art, poem, melody + WAV synth (stdlib only) |
| `app.py` | Flask routes, SQLite storage, audio/SVG endpoints |
| `templates/` | Jinja pages (create + gallery) |
| `static/` | CSS design system and front-end JS |
